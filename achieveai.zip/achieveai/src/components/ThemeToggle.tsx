"use client";
import { useEffect, useState } from "react";
import { SunIcon, MoonIcon } from "./Icons";
export default function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => setDark(document.documentElement.classList.contains("dark")), []);
  function toggle() {
    const next = !dark; setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try { localStorage.setItem("theme", next ? "dark" : "light"); } catch {}
  }
  return (
    <button role="switch" aria-checked={dark} aria-label="Dark mode" onClick={toggle}
      className="relative flex h-7 w-14 items-center justify-between rounded-full border border-line bg-card px-1.5 text-muted">
      <SunIcon /><MoonIcon />
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-accent transition-all ${dark ? "left-8" : "left-1"}`} />
    </button>
  );
}
