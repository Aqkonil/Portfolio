const p = { width: 16, height: 16, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
export const SunIcon = () => <svg {...p}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>;
export const MoonIcon = () => <svg {...p}><path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"/></svg>;
export const EyeIcon = () => <svg {...p}><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>;
export const EyeOffIcon = () => <svg {...p}><path d="M17.9 17.9A10.6 10.6 0 0112 19c-6.5 0-10-7-10-7a18 18 0 015.1-5.9M9.9 4.2A10 10 0 0112 4c6.5 0 10 8 10 8a18 18 0 01-2.2 3.2M1 1l22 22"/></svg>;
