"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase, configured } from "@/lib/supabase";
import { EyeIcon, EyeOffIcon } from "./Icons";
import ThemeToggle from "./ThemeToggle";

export default function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const router = useRouter();
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [show, setShow] = useState(false); const [loading, setLoading] = useState(false);
  const [error, setError] = useState(""); const [info, setInfo] = useState("");
  const isLogin = mode === "login";

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(""); setInfo(""); setLoading(true);
    if (isLogin) {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setError(error.message === "Email not confirmed" ? "Please verify your email first." : error.message);
      else router.push("/dashboard");
    } else {
      const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${location.origin}/dashboard` } });
      if (error) setError(error.message); else setInfo("Check your email and click the link to verify your account.");
    }
    setLoading(false);
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5">
      <div className="mb-6 flex items-center justify-between">
        <Link href="/" className="text-xl font-bold text-accent">AchieveAI</Link><ThemeToggle />
      </div>
      <form onSubmit={submit} className="card space-y-4">
        <h1 className="text-2xl font-bold">{isLogin ? "Sign In" : "Create Account"}</h1>
        {!configured && <p className="rounded-lg bg-yellow-100 p-3 text-sm text-yellow-900">Setup needed: add your Supabase keys to .env.local and restart the site.</p>}
        <label className="block text-sm">Email
          <input className="input mt-1" type="email" required value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" /></label>
        <label className="block text-sm">Password
          <div className="relative mt-1">
            <input className="input pr-11" type={show ? "text" : "password"} required minLength={8} value={password}
              onChange={e => setPassword(e.target.value)} autoComplete={isLogin ? "current-password" : "new-password"} />
            <button type="button" onClick={() => setShow(s => !s)} aria-pressed={show}
              aria-label={show ? "Hide password" : "Show password"} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted">
              {show ? <EyeOffIcon /> : <EyeIcon />}</button>
          </div></label>
        {error && <p role="alert" className="text-sm text-red-500">{error}</p>}
        {info && <p className="text-sm text-green-600">{info}</p>}
        <button className="btn w-full" disabled={loading || !configured}>{loading ? "Please wait..." : isLogin ? "Sign In" : "Create Account"}</button>
        <div className="flex justify-between text-sm text-muted">
          {isLogin ? <><Link href="/signup" className="text-accent">Create account</Link><Link href="/forgot">Forgot password?</Link></>
                   : <Link href="/login" className="text-accent">I already have an account</Link>}
        </div>
      </form>
    </main>
  );
}
