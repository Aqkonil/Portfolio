"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
import { STATUS_LABEL, LEVELS } from "@/lib/constants";
type A = { id: string; title: string; category: string; result: string | null; level: string; event_date: string | null; verification_status: string };
export default function Portfolio() {
  const [items, setItems] = useState<A[] | null>(null); const [err, setErr] = useState("");
  const load = () => supabase.from("achievements").select("id,title,category,result,level,event_date,verification_status").order("created_at", { ascending: false })
    .then(({ data, error }) => { if (error) setErr(error.message); setItems((data as A[]) ?? []); });
  useEffect(() => { load(); }, []);
  async function remove(id: string) {
    if (!confirm("Delete this achievement?")) return;
    const { error } = await supabase.from("achievements").delete().eq("id", id);
    if (error) setErr(error.message); else load();
  }
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between"><h1 className="text-3xl font-bold">My Portfolio</h1>
        <Link href="/portfolio/new" className="btn">Add Achievement</Link></div>
      {err && <p className="text-sm text-red-500">{err}</p>}
      {items === null ? <p className="text-muted">Loading...</p> : items.length === 0 ? <p className="card text-muted">Nothing here yet.</p> :
        items.map(a => (
          <div key={a.id} className="card flex items-start justify-between gap-4">
            <div><h2 className="font-semibold">{a.title}</h2>
              <p className="text-sm text-muted">{a.category} · {LEVELS.find(l => l[0] === a.level)?.[1]}{a.result ? ` · ${a.result}` : ""}{a.event_date ? ` · ${a.event_date}` : ""}</p>
              <p className="mt-2 inline-block rounded-full border border-line px-2.5 py-0.5 text-xs">{STATUS_LABEL[a.verification_status]}</p></div>
            <button onClick={() => remove(a.id)} className="text-sm text-red-500">Delete</button>
          </div>))}
    </div>
  );
}
