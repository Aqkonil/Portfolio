"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { CATEGORIES, LEVELS } from "@/lib/constants";
const L = ({ t, children }: { t: string; children: React.ReactNode }) => <label className="block text-sm">{t}<div className="mt-1">{children}</div></label>;
export default function NewAchievement() {
  const router = useRouter(); const [err, setErr] = useState(""); const [loading, setLoading] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setErr(""); setLoading(true);
    const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { router.replace("/login"); return; }
    const { error } = await supabase.from("achievements").insert({
      user_id: user.id, title: f.title, description: f.description || null, category: f.category, event_name: f.event_name || null,
      organizer: f.organizer || null, event_date: f.event_date || null, result: f.result || null, level: f.level, project_url: f.project_url || null });
    setLoading(false);
    if (error) setErr(error.message); else router.push("/portfolio");
  }
  return (
    <form onSubmit={submit} className="card mx-auto max-w-xl space-y-4">
      <h1 className="text-2xl font-bold">Add Achievement</h1>
      <L t="Title"><input name="title" required className="input" /></L>
      <L t="Description"><textarea name="description" rows={3} className="input" /></L>
      <L t="Category"><select name="category" className="input">{CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></L>
      <L t="Competition or event name"><input name="event_name" className="input" /></L>
      <L t="Organizer"><input name="organizer" className="input" /></L>
      <L t="Date"><input name="event_date" type="date" className="input" /></L>
      <L t="Result or award"><input name="result" className="input" /></L>
      <L t="Level (the real size of the event)"><select name="level" className="input">{LEVELS.map(([v, n]) => <option key={v} value={v}>{n}</option>)}</select></L>
      <L t="Project link (optional)"><input name="project_url" type="url" className="input" /></L>
      {err && <p className="text-sm text-red-500">{err}</p>}
      <button className="btn w-full" disabled={loading}>{loading ? "Saving..." : "Save achievement"}</button>
    </form>
  );
}
