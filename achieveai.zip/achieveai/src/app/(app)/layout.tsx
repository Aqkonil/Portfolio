"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import ThemeToggle from "@/components/ThemeToggle";
export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter(); const [ready, setReady] = useState(false);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { if (!data.session) router.replace("/login"); else setReady(true); });
  }, [router]);
  if (!ready) return <p className="p-8 text-muted">Loading...</p>;
  return (
    <div className="mx-auto max-w-5xl px-5 py-5">
      <nav className="mb-8 flex items-center justify-between">
        <div className="flex items-center gap-5 text-sm">
          <Link href="/dashboard" className="text-xl font-bold text-accent">AchieveAI</Link>
          <Link href="/dashboard">Dashboard</Link><Link href="/portfolio">My Portfolio</Link>
        </div>
        <div className="flex items-center gap-4"><ThemeToggle />
          <button className="text-sm text-muted" onClick={async () => { await supabase.auth.signOut(); router.push("/login"); }}>Sign Out</button></div>
      </nav>
      {children}
    </div>
  );
}
