"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
export default function Dashboard() {
  const [rows, setRows] = useState<{ verification_status: string }[] | null>(null);
  useEffect(() => { supabase.from("achievements").select("verification_status").then(({ data }) => setRows(data ?? [])); }, []);
  if (!rows) return <p className="text-muted">Loading...</p>;
  const total = rows.length;
  const verified = rows.filter(r => ["verified_official_source", "reviewed_by_reviewer"].includes(r.verification_status)).length;
  const pending = rows.filter(r => ["processing", "pending_confirmation", "needs_manual_review"].includes(r.verification_status)).length;
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Welcome back</h1>
      {total === 0 ? (
        <div className="card text-center"><p className="text-muted">You have no achievements yet. Add your first one to start your portfolio.</p>
          <Link href="/portfolio/new" className="btn mt-4 inline-block">Add first achievement</Link></div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-3">
          {[["Total achievements", total], ["Verified", verified], ["Pending reviews", pending]].map(([l, n]) => (
            <div key={l as string} className="card"><p className="text-sm text-muted">{l}</p><p className="text-3xl font-bold">{n}</p></div>))}
        </div>
      )}
    </div>
  );
}
