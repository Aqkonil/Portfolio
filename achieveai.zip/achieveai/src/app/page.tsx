import Link from "next/link";
import ThemeToggle from "@/components/ThemeToggle";
export default function Landing() {
  return (
    <main className="mx-auto max-w-4xl px-5 py-6">
      <header className="flex items-center justify-between">
        <span className="text-xl font-bold text-accent">AchieveAI</span>
        <div className="flex items-center gap-4"><ThemeToggle /><Link href="/login" className="text-sm">Sign In</Link></div>
      </header>
      <section className="py-24 text-center">
        <h1 className="text-4xl font-extrabold sm:text-5xl">Build your student portfolio.<br /><span className="text-accent">Plan your university path.</span></h1>
        <p className="mx-auto mt-5 max-w-xl text-muted">Save your achievements, share them with one QR code, and get clear steps for university admission.</p>
        <div className="mt-8 flex justify-center gap-3">
          <Link href="/signup" className="btn">Create Account</Link>
          <Link href="/login" className="rounded-xl border border-line px-5 py-2.5 font-semibold">Sign In</Link>
        </div>
      </section>
    </main>
  );
}
