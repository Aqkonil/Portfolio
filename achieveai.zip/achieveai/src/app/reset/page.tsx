"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
export default function Reset() {
  const router = useRouter(); const [pw, setPw] = useState(""); const [err, setErr] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    const { error } = await supabase.auth.updateUser({ password: pw });
    if (error) setErr(error.message); else router.push("/dashboard");
  }
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5">
      <form onSubmit={submit} className="card space-y-4">
        <h1 className="text-2xl font-bold">New Password</h1>
        <input className="input" type="password" required minLength={8} placeholder="New password (8+ characters)" value={pw} onChange={e => setPw(e.target.value)} />
        {err && <p className="text-sm text-red-500">{err}</p>}
        <button className="btn w-full">Save password</button>
      </form>
    </main>
  );
}
