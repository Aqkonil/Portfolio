import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "AchieveAI", description: "Save your achievements and plan your university path." };
const themeScript = `try{if(localStorage.getItem('theme')==='dark')document.documentElement.classList.add('dark')}catch(e){}`;
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body className="min-h-screen font-sans antialiased">{children}</body>
    </html>
  );
}
