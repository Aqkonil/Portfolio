"use client";
import { useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
export default function Forgot() {
  const [email, setEmail] = useState(""); const [msg, setMsg] = useState(""); const [err, setErr] = useState(""); const [loading, setLoading] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(""); setMsg(""); setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${location.origin}/reset` });
    if (error) setErr(error.message); else setMsg("If this email has an account, we sent a reset link.");
    setLoading(false);
  }
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5">
      <form onSubmit={submit} className="card space-y-4">
        <h1 className="text-2xl font-bold">Forgot Password</h1>
        <input className="input" type="email" required placeholder="Your email" value={email} onChange={e => setEmail(e.target.value)} />
        {err && <p className="text-sm text-red-500">{err}</p>}{msg && <p className="text-sm text-green-600">{msg}</p>}
        <button className="btn w-full" disabled={loading}>{loading ? "Please wait..." : "Send reset link"}</button>
        <Link href="/login" className="text-sm text-accent">Back to Sign In</Link>
      </form>
    </main>
  );
}
