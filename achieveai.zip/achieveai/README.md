# AchieveAI
1. `npm install`
2. Copy `.env.example` to `.env.local` and paste your Supabase publishable (anon) key.
3. `npm run dev` and open http://localhost:3000
