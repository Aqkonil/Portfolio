import type { Config } from "tailwindcss";
const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: { extend: { colors: {
    bg: "var(--bg)", card: "var(--card)", ink: "var(--text)",
    muted: "var(--muted)", line: "var(--border)", accent: "var(--accent)" } } },
  plugins: [],
};
export default config;
